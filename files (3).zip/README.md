# 🤖 Task 6 — AI-Powered Indoor Obstacle Avoidance

## Overview
A complete AI perception + control loop that navigates indoor spaces while detecting and avoiding obstacles — built for robot/drone context.

**Difficulty:** Advanced | **Tech:** Python, OpenCV, NumPy

---

## Setup & Run

```bash
pip install -r requirements.txt
python obstacle_avoidance.py
```

All outputs saved to `outputs/` folder automatically.

---

## System Architecture

### 1. 🏠 Indoor Environment Simulation
- Procedurally generated realistic floor plan (rooms, walls, doorways)
- Furniture obstacles: sofa, tables, chairs, shelves, cabinets
- Binary occupancy grid for path planning
- 600×500 pixel map at 1:50 real-world scale

### 2. 📷 Obstacle Detection (Classical CV)
| Step | Method |
|---|---|
| Preprocessing | Grayscale + Gaussian blur (noise reduction) |
| Edge detection | Canny edge detector (threshold 50/150) |
| Gap filling | Morphological closing (5×5 kernel) |
| Object extraction | Contour detection + bounding boxes |
| Distance estimation | Euclidean distance from robot position |
| Danger classification | CRITICAL / WARNING / CLEAR zones |

### 3. 🗺️ A* Path Planning
- **8-directional** grid movement (diagonal allowed)
- **Euclidean distance** heuristic
- **Obstacle inflation** (12px safety margin via morphological dilation)
- **Path smoothing** (moving-average filter, window=7)
- Handles blocked start/goal by finding nearest free cell

### 4. 🎮 Control Heuristics (Pure Pursuit)
- **Lookahead point** selection on planned path
- **Steering angle** → angular velocity command
- **Speed scaling** near obstacles (40% speed in warning zone)
- **Emergency stop** on critical obstacle detection
- Heading tracking with angular correction

### 5. 🛡️ Safety System (3-Tier)
| Zone | Distance | Action |
|---|---|---|
| 🔴 CRITICAL | < 30 px | Emergency stop |
| 🟠 WARNING | < 75 px | Slow down + steer away |
| 🟢 CLEAR | > 75 px | Normal navigation |

### 6. 🔧 Sim-to-Real Considerations
- Velocity scaling (sim pixels → real m/s)
- Distance calibration (1px ≈ 0.02m at 1:50 scale)
- Sensor noise modeling (Gaussian σ=2px for lidar simulation)
- Actuation lag (50–100ms)
- ROS integration hints (/cmd_vel, /scan, /odom topics)

---

## Outputs
| File | Description |
|---|---|
| `floor_plan.png` | Generated indoor map with obstacles |
| `detection_result.png` | OpenCV obstacle detection annotated |
| `obstacle_avoidance_results.png` | Full 6-panel visualization |
| `obstacle_avoidance_report.html` | Interactive HTML report |

---

## Real-World Applications
- 🏭 Warehouse autonomous mobile robots (AMRs)
- 🏠 Home service robots
- 🚁 Indoor delivery drones
- ♿ Smart mobility aids

---

## Libraries
- `opencv-python` — Obstacle detection, image processing
- `numpy` — Grid operations, math
- `matplotlib` — Visualization
- (optional) `tensorflow/pytorch` — For DL-based detection upgrade
- (optional) `ROS` — For real hardware deployment
