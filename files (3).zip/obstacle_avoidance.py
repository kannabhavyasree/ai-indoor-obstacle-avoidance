"""
=============================================================
  Task 6 — AI-Powered Indoor Obstacle Avoidance
=============================================================
Tech:    Python, OpenCV, NumPy
Methods: Classical obstacle detection (contours + depth
         simulation), path planning (A* algorithm),
         control heuristics, safety checks,
         sim-to-real considerations
Real-World: Service robots, autonomous drones,
            smart mobility in warehouses/homes
=============================================================
Run:  python obstacle_avoidance.py
=============================================================
"""

import cv2
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap
import heapq
import math
import os
import json
from datetime import datetime
from collections import defaultdict

# ── Output directory ───────────────────────────────────────
OUT_DIR = 'outputs'
os.makedirs(OUT_DIR, exist_ok=True)

# ══════════════════════════════════════════════════════════
#  PART 1: INDOOR FLOOR PLAN GENERATOR
#  Simulates what a robot's map/camera would see
# ══════════════════════════════════════════════════════════

def generate_indoor_floorplan(width=600, height=500):
    """
    Generate a realistic indoor floor plan with:
    - Walls (outer + room dividers)
    - Furniture obstacles (tables, chairs, shelves)
    - Doorways (navigable gaps)
    - Free space (navigable floor)
    Returns: BGR image + binary occupancy grid
    """
    # White background = free space
    img = np.ones((height, width, 3), dtype=np.uint8) * 245

    # Occupancy grid: 0=free, 1=obstacle
    grid = np.zeros((height, width), dtype=np.uint8)

    def draw_wall(x1, y1, x2, y2, thickness=8):
        cv2.rectangle(img, (x1, y1), (x2, y2), (40, 40, 40), -1)
        grid[y1:y2, x1:x2] = 1

    def draw_obstacle(x1, y1, x2, y2, color=(100, 80, 60), label=""):
        cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)
        cv2.rectangle(img, (x1, y1), (x2, y2), (20, 20, 20), 2)
        grid[y1:y2, x1:x2] = 1
        if label:
            cx, cy = (x1+x2)//2, (y1+y2)//2
            cv2.putText(img, label, (cx-18, cy+4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255,255,255), 1)

    # ── Outer walls ──
    draw_wall(0, 0, width, 8)          # top
    draw_wall(0, height-8, width, height)  # bottom
    draw_wall(0, 0, 8, height)         # left
    draw_wall(width-8, 0, width, height)   # right

    # ── Room dividers (inner walls with doorways) ──
    # Vertical wall room 1|2 — doorway at y=180..230
    draw_wall(200, 8,   208, 170)
    draw_wall(200, 240, 208, height-8)

    # Horizontal wall room 2|3 — doorway at x=320..380
    draw_wall(208, 250, 310, 258)
    draw_wall(390, 250, width-8, 258)

    # ── Furniture obstacles ──
    # Room 1 (left): sofa + coffee table + shelf
    draw_obstacle(30,  50,  130, 110, (139, 90, 43),  "sofa")
    draw_obstacle(50,  120, 110, 155, (180, 140, 80), "table")
    draw_obstacle(30,  200, 80,  350, (80,  60,  40), "shelf")
    draw_obstacle(110, 380, 180, 440, (100, 80,  60), "chair")

    # Room 2 (top-right): desk + chair + cabinet
    draw_obstacle(260, 30,  370, 90,  (100, 120, 160), "desk")
    draw_obstacle(380, 30,  430, 80,  (80,  100, 130), "cabinet")
    draw_obstacle(260, 100, 310, 150, (120, 140, 180), "chair")
    draw_obstacle(470, 20,  560, 100, (90,  70,  50),  "shelf")
    draw_obstacle(460, 140, 530, 200, (110, 90,  70),  "box")

    # Room 3 (bottom-right): dining table + chairs
    draw_obstacle(300, 300, 450, 380, (160, 120, 80), "table")
    draw_obstacle(270, 300, 298, 340, (120, 100, 60), "chair")
    draw_obstacle(452, 300, 480, 340, (120, 100, 60), "chair")
    draw_obstacle(300, 382, 340, 410, (120, 100, 60), "chair")
    draw_obstacle(410, 382, 450, 410, (120, 100, 60), "chair")
    draw_obstacle(490, 310, 570, 430, (80,  60,  40), "shelf")

    # ── Floor pattern (subtle grid) ──
    for x in range(0, width, 40):
        cv2.line(img, (x, 0), (x, height), (220, 220, 220), 1)
    for y in range(0, height, 40):
        cv2.line(img, (0, y), (width, y), (220, 220, 220), 1)

    # Re-draw obstacles on top of grid lines
    # (already done via numpy grid, just return)

    return img, grid


# ══════════════════════════════════════════════════════════
#  PART 2: OBSTACLE DETECTION (Classical Computer Vision)
# ══════════════════════════════════════════════════════════

class ObstacleDetector:
    """
    Classical CV obstacle detection pipeline:
    1. Grayscale conversion
    2. Gaussian blur (noise reduction)
    3. Adaptive thresholding / Canny edge detection
    4. Contour detection + bounding boxes
    5. Depth simulation (distance estimation)
    6. Safety zone classification
    """

    def __init__(self, robot_fov_deg=90, max_range_px=200):
        self.fov      = robot_fov_deg
        self.max_range = max_range_px
        self.safety_radius = 30   # pixels — minimum safe distance

    def detect(self, frame: np.ndarray, robot_pos: tuple) -> dict:
        """
        Detect obstacles in frame relative to robot position.
        Returns dict with detected obstacles + annotated frame.
        """
        gray     = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred  = cv2.GaussianBlur(gray, (5, 5), 0)

        # ── Edge detection ──
        edges = cv2.Canny(blurred, threshold1=50, threshold2=150)

        # ── Morphological closing to fill gaps ──
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
        closed = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

        # ── Contour detection ──
        contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)

        obstacles = []
        annotated = frame.copy()
        rx, ry    = robot_pos

        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area < 300:   # ignore tiny noise
                continue

            x, y, w, h = cv2.boundingRect(cnt)
            cx, cy     = x + w//2, y + h//2

            # ── Distance from robot (simulated depth) ──
            dist = math.hypot(cx - rx, cy - ry)

            # ── Safety classification ──
            if dist < self.safety_radius:
                danger = "CRITICAL"
                color  = (0, 0, 255)
            elif dist < self.safety_radius * 2.5:
                danger = "WARNING"
                color  = (0, 165, 255)
            else:
                danger = "CLEAR"
                color  = (0, 200, 0)

            # ── Bearing angle ──
            angle = math.degrees(math.atan2(cy - ry, cx - rx))

            obstacles.append({
                'bbox':    (x, y, w, h),
                'center':  (cx, cy),
                'area':    area,
                'dist':    round(dist, 1),
                'angle':   round(angle, 1),
                'danger':  danger,
                'color':   color,
            })

            # ── Annotate frame ──
            cv2.rectangle(annotated, (x, y), (x+w, y+h), color, 2)
            cv2.circle(annotated, (cx, cy), 4, color, -1)
            label = f"{danger} d={dist:.0f}px"
            cv2.putText(annotated, label, (x, y-6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1)

        # Draw robot position
        cv2.circle(annotated, robot_pos, 12, (255, 100, 0), -1)
        cv2.circle(annotated, robot_pos, 12, (255, 255, 255), 2)
        cv2.putText(annotated, "ROBOT", (rx-22, ry+28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 100, 0), 1)

        # FOV arc
        fov_r = self.max_range
        cv2.ellipse(annotated, robot_pos,
                    (fov_r, fov_r), 0, -self.fov//2, self.fov//2,
                    (255, 200, 100), 1)

        return {
            'obstacles':   obstacles,
            'annotated':   annotated,
            'edges':       edges,
            'n_critical':  sum(1 for o in obstacles if o['danger'] == 'CRITICAL'),
            'n_warning':   sum(1 for o in obstacles if o['danger'] == 'WARNING'),
            'n_clear':     sum(1 for o in obstacles if o['danger'] == 'CLEAR'),
        }


# ══════════════════════════════════════════════════════════
#  PART 3: A* PATH PLANNING
# ══════════════════════════════════════════════════════════

class AStarPlanner:
    """
    A* path planning on occupancy grid.
    - 8-directional movement
    - Obstacle inflation (safety margin)
    - Heuristic: Euclidean distance
    """

    def __init__(self, grid: np.ndarray, inflation_radius: int = 15):
        self.raw_grid = grid
        self.grid     = self._inflate(grid, inflation_radius)
        self.h, self.w = grid.shape

    def _inflate(self, grid: np.ndarray, radius: int) -> np.ndarray:
        """Expand obstacles by radius pixels for safety margin."""
        kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE, (radius*2+1, radius*2+1))
        inflated = cv2.dilate(grid.astype(np.uint8), kernel)
        return inflated

    def _heuristic(self, a, b):
        # Euclidean distance
        return math.hypot(b[0]-a[0], b[1]-a[1])

    def plan(self, start: tuple, goal: tuple) -> list:
        """
        Find shortest path from start to goal.
        start/goal = (row, col) in grid coordinates.
        Returns list of (row, col) waypoints or [] if no path.
        """
        # Clamp to grid
        sr, sc = max(0,min(self.h-1, start[0])), max(0,min(self.w-1, start[1]))
        gr, gc = max(0,min(self.h-1, goal[0])),  max(0,min(self.w-1, goal[1]))

        if self.grid[sr, sc] == 1 or self.grid[gr, gc] == 1:
            print("   ⚠️  Start or goal is in obstacle — trying nearby free cell")
            sr, sc = self._nearest_free(sr, sc)
            gr, gc = self._nearest_free(gr, gc)

        open_heap = []
        heapq.heappush(open_heap, (0, (sr, sc)))
        came_from = {}
        g_score   = defaultdict(lambda: float('inf'))
        g_score[(sr, sc)] = 0

        # 8-directional moves: (dr, dc, cost)
        moves = [(-1,0,1),(1,0,1),(0,-1,1),(0,1,1),
                 (-1,-1,1.414),(-1,1,1.414),(1,-1,1.414),(1,1,1.414)]

        while open_heap:
            _, current = heapq.heappop(open_heap)
            if current == (gr, gc):
                return self._reconstruct(came_from, current)

            cr, cc = current
            for dr, dc, cost in moves:
                nr, nc = cr+dr, cc+dc
                if 0 <= nr < self.h and 0 <= nc < self.w:
                    if self.grid[nr, nc] == 1:
                        continue
                    tentative_g = g_score[current] + cost
                    if tentative_g < g_score[(nr, nc)]:
                        came_from[(nr, nc)] = current
                        g_score[(nr, nc)]   = tentative_g
                        f = tentative_g + self._heuristic((nr,nc),(gr,gc))
                        heapq.heappush(open_heap, (f, (nr, nc)))

        return []  # No path found

    def _nearest_free(self, r, c, search_r=30):
        for radius in range(1, search_r):
            for dr in range(-radius, radius+1):
                for dc in range(-radius, radius+1):
                    nr, nc = r+dr, c+dc
                    if 0 <= nr < self.h and 0 <= nc < self.w:
                        if self.grid[nr, nc] == 0:
                            return nr, nc
        return r, c

    def _reconstruct(self, came_from, current):
        path = [current]
        while current in came_from:
            current = came_from[current]
            path.append(current)
        path.reverse()
        return path

    def smooth_path(self, path: list, window: int = 5) -> list:
        """Moving-average path smoothing."""
        if len(path) < window:
            return path
        smoothed = []
        for i in range(len(path)):
            start = max(0, i - window//2)
            end   = min(len(path), i + window//2 + 1)
            avg_r = int(np.mean([p[0] for p in path[start:end]]))
            avg_c = int(np.mean([p[1] for p in path[start:end]]))
            smoothed.append((avg_r, avg_c))
        return smoothed


# ══════════════════════════════════════════════════════════
#  PART 4: CONTROL HEURISTICS
# ══════════════════════════════════════════════════════════

class RobotController:
    """
    Control heuristics for robot navigation:
    - Pure pursuit (follow waypoints)
    - Obstacle reactive avoidance
    - Safety checks
    - Sim-to-real velocity scaling
    """

    def __init__(self, lookahead_dist=40, max_speed=1.0,
                 max_angular=1.5, safety_dist=30):
        self.lookahead   = lookahead_dist
        self.max_speed   = max_speed        # m/s (sim-to-real scaling)
        self.max_angular = max_angular      # rad/s
        self.safety_dist = safety_dist
        self.heading     = 0.0              # current heading (degrees)
        self.log         = []

    def compute_command(self, robot_pos: tuple, path: list,
                        obstacles: list, step: int) -> dict:
        """
        Compute velocity commands given:
        - robot_pos: current (x, y)
        - path: remaining waypoints [(r,c), ...]
        - obstacles: detected obstacle list
        Returns: {'linear': float, 'angular': float, 'action': str}
        """
        rx, ry = robot_pos

        # ── Safety check: stop if critical obstacle ──
        critical = [o for o in obstacles if o['danger'] == 'CRITICAL']
        if critical:
            closest = min(critical, key=lambda o: o['dist'])
            action = f"EMERGENCY STOP — obstacle at {closest['dist']:.0f}px"
            cmd = {'linear': 0.0, 'angular': 0.0, 'action': action,
                   'safe': False}
            self.log.append({'step': step, **cmd})
            return cmd

        # ── Warning: slow down + steer away ──
        warnings = [o for o in obstacles if o['danger'] == 'WARNING']
        speed_scale = 1.0
        avoid_angular = 0.0
        if warnings:
            speed_scale = 0.4
            # Steer away from average bearing
            avg_angle = np.mean([o['angle'] for o in warnings])
            avoid_angular = -0.5 if avg_angle > 0 else 0.5

        # ── Pure pursuit: find lookahead point ──
        if len(path) < 2:
            cmd = {'linear': 0.0, 'angular': 0.0,
                   'action': 'GOAL REACHED', 'safe': True}
            self.log.append({'step': step, **cmd})
            return cmd

        # Find closest waypoint ahead
        target = None
        for wp in path:
            wc, wr = wp[1], wp[0]   # grid (row,col) → image (x,y)
            dist   = math.hypot(wc - rx, wr - ry)
            if dist >= self.lookahead:
                target = (wc, wr)
                break
        if target is None:
            target = (path[-1][1], path[-1][0])

        # ── Steering angle ──
        tx, ty   = target
        angle_to = math.degrees(math.atan2(ty - ry, tx - rx))
        delta    = angle_to - self.heading
        # Normalize to [-180, 180]
        delta = (delta + 180) % 360 - 180

        angular  = np.clip(delta * 0.03 + avoid_angular,
                           -self.max_angular, self.max_angular)
        linear   = self.max_speed * speed_scale * (1 - abs(angular)/self.max_angular * 0.5)
        linear   = max(0.05, linear)

        self.heading += angular * 10   # simulate heading update

        action = "NAVIGATE" if not warnings else "NAVIGATE (slow — obstacles nearby)"
        cmd = {
            'linear':  round(linear, 3),
            'angular': round(angular, 3),
            'action':  action,
            'safe':    True,
            'target':  target,
        }
        self.log.append({'step': step, **cmd})
        return cmd

    def sim_to_real_check(self) -> dict:
        """
        Sim-to-real considerations summary.
        In simulation, distances are pixels; real robot uses meters.
        """
        return {
            'velocity_scale':    '1 sim-unit = 0.01 m/s (scale for real robot)',
            'distance_scale':    '1 pixel ≈ 0.02 m at 1:50 map scale',
            'sensor_noise':      'Add Gaussian noise σ=2px to simulate real lidar',
            'actuation_lag':     '50–100ms latency expected on real hardware',
            'map_update_rate':   '10 Hz recommended for indoor SLAM',
            'safety_margin':     '0.3m minimum clearance (≈15px at 1:50 scale)',
            'communication':     'ROS topics: /cmd_vel, /scan, /odom',
        }


# ══════════════════════════════════════════════════════════
#  PART 5: SIMULATION RUNNER
# ══════════════════════════════════════════════════════════

def run_simulation(start_px, goal_px, n_steps=20):
    """
    Full perception + planning + control simulation.
    start_px / goal_px = (x, y) in image coordinates.
    """
    print("\n" + "="*65)
    print("  🤖  AI-POWERED INDOOR OBSTACLE AVOIDANCE — Task 6")
    print("="*65)

    # ── Generate environment ──
    print("\n📐 Generating indoor floor plan...")
    floor_img, grid = generate_indoor_floorplan()
    print(f"   Map size: {grid.shape[1]}×{grid.shape[0]} px")
    print(f"   Obstacle cells: {grid.sum():,} / {grid.size:,} ({grid.mean()*100:.1f}%)")

    # ── Obstacle detection ──
    print("\n🔍 Running obstacle detection (OpenCV)...")
    detector  = ObstacleDetector()
    detection = detector.detect(floor_img, start_px)
    print(f"   Obstacles found : {len(detection['obstacles'])}")
    print(f"   CRITICAL zones  : {detection['n_critical']}")
    print(f"   WARNING zones   : {detection['n_warning']}")
    print(f"   CLEAR zones     : {detection['n_clear']}")

    # ── A* path planning ──
    print("\n🗺️  Running A* path planning...")
    # Convert (x,y) image coords to (row,col) grid coords
    start_grid = (start_px[1], start_px[0])
    goal_grid  = (goal_px[1],  goal_px[0])
    planner    = AStarPlanner(grid, inflation_radius=12)
    raw_path   = planner.plan(start_grid, goal_grid)

    if not raw_path:
        print("   ❌ No path found — all routes blocked!")
        path = []
    else:
        path = planner.smooth_path(raw_path, window=7)
        path_len = sum(
            math.hypot(path[i+1][1]-path[i][1], path[i+1][0]-path[i][0])
            for i in range(len(path)-1))
        print(f"   Raw waypoints   : {len(raw_path)}")
        print(f"   Smoothed wps    : {len(path)}")
        print(f"   Path length     : {path_len:.0f} px  ≈ {path_len*0.02:.1f} m")

    # ── Control simulation ──
    print(f"\n🎮 Simulating robot control ({n_steps} steps)...")
    controller = RobotController()
    robot_pos  = list(start_px)
    trajectory = [tuple(robot_pos)]
    remaining  = path.copy()

    for step in range(n_steps):
        # Update remaining path (remove passed waypoints)
        remaining = [wp for wp in remaining
                     if math.hypot(wp[1]-robot_pos[0], wp[0]-robot_pos[1]) > 20]

        cmd = controller.compute_command(
            tuple(robot_pos), remaining,
            detection['obstacles'], step)

        if cmd['action'] == 'GOAL REACHED':
            print(f"   ✅ Goal reached at step {step}!")
            break

        # Move robot along command
        if cmd['safe'] and 'target' in cmd:
            tx, ty  = cmd['target']
            dist    = math.hypot(tx-robot_pos[0], ty-robot_pos[1])
            if dist > 0:
                robot_pos[0] += int((tx-robot_pos[0]) / dist * cmd['linear'] * 15)
                robot_pos[1] += int((ty-robot_pos[1]) / dist * cmd['linear'] * 15)

        trajectory.append(tuple(robot_pos))

        if step < 5 or step % 5 == 0:
            print(f"   Step {step:02d}: pos=({robot_pos[0]:3d},{robot_pos[1]:3d}) "
                  f"v={cmd['linear']:.2f} ω={cmd['angular']:.2f} → {cmd['action'][:35]}")

    # ── Sim-to-real ──
    s2r = controller.sim_to_real_check()
    print("\n🔧 Sim-to-Real Considerations:")
    for k, v in s2r.items():
        print(f"   {k:<20}: {v}")

    return {
        'floor_img':   floor_img,
        'grid':        grid,
        'detection':   detection,
        'planner':     planner,
        'path':        path,
        'raw_path':    raw_path,
        'trajectory':  trajectory,
        'controller':  controller,
        'start':       start_px,
        'goal':        goal_px,
        's2r':         s2r,
    }


# ══════════════════════════════════════════════════════════
#  PART 6: VISUALISATION
# ══════════════════════════════════════════════════════════

def visualize_all(sim: dict):
    print("\n📊 Generating visualizations...")

    fig = plt.figure(figsize=(20, 16))
    fig.patch.set_facecolor('#0a0c10')

    # ── 1. Floor plan + path overlay ──
    ax1 = fig.add_subplot(2, 3, 1)
    ax1.set_facecolor('#111318')
    floor_rgb = cv2.cvtColor(sim['floor_img'], cv2.COLOR_BGR2RGB)
    ax1.imshow(floor_rgb)

    # Draw inflated grid overlay (semi-transparent)
    inflated = sim['planner'].grid
    overlay  = np.zeros((*inflated.shape, 4), dtype=np.float32)
    overlay[inflated == 1] = [1, 0.2, 0.2, 0.25]
    ax1.imshow(overlay)

    # Draw raw path
    if sim['raw_path']:
        rp = sim['raw_path']
        ax1.plot([p[1] for p in rp], [p[0] for p in rp],
                 'cyan', lw=1, alpha=0.4, label='Raw path')

    # Draw smooth path
    if sim['path']:
        sp = sim['path']
        ax1.plot([p[1] for p in sp], [p[0] for p in sp],
                 'lime', lw=2.5, label='Smooth path', zorder=5)
        # Waypoint markers
        for i, wp in enumerate(sp[::max(1, len(sp)//10)]):
            ax1.plot(wp[1], wp[0], 'o', color='lime',
                     ms=5, zorder=6, alpha=0.8)

    # Draw trajectory
    if len(sim['trajectory']) > 1:
        traj = sim['trajectory']
        ax1.plot([t[0] for t in traj], [t[1] for t in traj],
                 'orange', lw=2, ls='--', label='Robot trajectory', zorder=7)

    # Start + Goal markers
    sx, sy = sim['start']
    gx, gy = sim['goal']
    ax1.plot(sx, sy, 's', color='#00aaff', ms=14, zorder=10, label='Start')
    ax1.plot(gx, gy, '*', color='#ffaa00', ms=18, zorder=10, label='Goal')
    ax1.legend(fontsize=7, facecolor='#161a22', labelcolor='white',
               loc='upper right')
    ax1.set_title('Floor Plan + A* Path Planning', color='white', fontsize=11)
    ax1.axis('off')

    # ── 2. Obstacle detection annotated ──
    ax2 = fig.add_subplot(2, 3, 2)
    ax2.set_facecolor('#111318')
    det_rgb = cv2.cvtColor(sim['detection']['annotated'], cv2.COLOR_BGR2RGB)
    ax2.imshow(det_rgb)
    ax2.set_title('Obstacle Detection (OpenCV)', color='white', fontsize=11)
    ax2.axis('off')
    # Stats overlay
    stats = (f"Detected: {len(sim['detection']['obstacles'])}  "
             f"Critical: {sim['detection']['n_critical']}  "
             f"Warning: {sim['detection']['n_warning']}")
    ax2.text(5, 480, stats, color='white', fontsize=7.5,
             bbox=dict(facecolor='#0a0c10', alpha=0.7, pad=3))

    # ── 3. Edge detection ──
    ax3 = fig.add_subplot(2, 3, 3)
    ax3.set_facecolor('#111318')
    ax3.imshow(sim['detection']['edges'], cmap='hot')
    ax3.set_title('Canny Edge Detection', color='white', fontsize=11)
    ax3.axis('off')

    # ── 4. Occupancy grid ──
    ax4 = fig.add_subplot(2, 3, 4)
    ax4.set_facecolor('#111318')
    cmap = ListedColormap(['#1a2a1a', '#e84040'])
    ax4.imshow(sim['grid'], cmap=cmap, interpolation='nearest')

    if sim['path']:
        sp = sim['path']
        ax4.plot([p[1] for p in sp], [p[0] for p in sp],
                 'lime', lw=2, label='A* path')
    ax4.plot(sim['start'][0], sim['start'][1], 's',
             color='#00aaff', ms=10, label='Start')
    ax4.plot(sim['goal'][0], sim['goal'][1], '*',
             color='#ffaa00', ms=14, label='Goal')
    ax4.legend(fontsize=7, facecolor='#0a0c10', labelcolor='white')
    ax4.set_title('Occupancy Grid + A* Path', color='white', fontsize=11)
    ax4.tick_params(colors='#666')

    # ── 5. Control commands over time ──
    ax5 = fig.add_subplot(2, 3, 5)
    ax5.set_facecolor('#111318')
    log  = sim['controller'].log
    if log:
        steps    = [e['step']    for e in log]
        linears  = [e['linear']  for e in log]
        angulars = [e['angular'] for e in log]
        ax5.plot(steps, linears,  color='#4f8ef7', lw=2, label='Linear vel (m/s)')
        ax5.plot(steps, angulars, color='#f07820', lw=2, label='Angular vel (rad/s)')
        ax5.axhline(0, color='#444', lw=1)
        ax5.set_xlabel('Step', color='#888')
        ax5.set_ylabel('Velocity', color='#888')
        ax5.legend(facecolor='#161a22', labelcolor='white', fontsize=8)
        ax5.tick_params(colors='#888')
        for sp in ax5.spines.values():
            sp.set_edgecolor('#1e2330')
    ax5.set_title('Robot Control Commands', color='white', fontsize=11)

    # ── 6. Distance to obstacles over steps ──
    ax6 = fig.add_subplot(2, 3, 6)
    ax6.set_facecolor('#111318')
    obs = sim['detection']['obstacles']
    if obs:
        sorted_obs = sorted(obs, key=lambda o: o['dist'])[:8]
        labels     = [f"Obs{i+1}" for i in range(len(sorted_obs))]
        dists      = [o['dist']   for o in sorted_obs]
        colors_obs = ['#f04040' if o['danger']=='CRITICAL'
                      else '#f07820' if o['danger']=='WARNING'
                      else '#30c060' for o in sorted_obs]
        bars = ax6.barh(labels, dists, color=colors_obs, alpha=0.85)
        ax6.axvline(30,  color='red',    ls='--', lw=1.5, label='Critical (<30px)')
        ax6.axvline(75,  color='orange', ls='--', lw=1.5, label='Warning (<75px)')
        ax6.set_xlabel('Distance (px)', color='#888')
        ax6.legend(facecolor='#161a22', labelcolor='white', fontsize=7)
        ax6.tick_params(colors='#888')
        for sp in ax6.spines.values():
            sp.set_edgecolor('#1e2330')
    ax6.set_title('Obstacle Distance Map', color='white', fontsize=11)

    plt.suptitle('Task 6 — AI-Powered Indoor Obstacle Avoidance System',
                 color='white', fontsize=14, y=1.005, fontweight='bold')
    plt.tight_layout()
    path_out = os.path.join(OUT_DIR, 'obstacle_avoidance_results.png')
    plt.savefig(path_out, dpi=150, bbox_inches='tight', facecolor='#0a0c10')
    plt.close()
    print(f"   📊 Main visualization saved → {path_out}")

    # ── Save floor plan separately ──
    fp_out = os.path.join(OUT_DIR, 'floor_plan.png')
    cv2.imwrite(fp_out, sim['floor_img'])
    print(f"   🗺️  Floor plan saved → {fp_out}")

    # ── Save detection result ──
    det_out = os.path.join(OUT_DIR, 'detection_result.png')
    cv2.imwrite(det_out, sim['detection']['annotated'])
    print(f"   🔍 Detection result saved → {det_out}")


# ══════════════════════════════════════════════════════════
#  PART 7: HTML REPORT
# ══════════════════════════════════════════════════════════

def generate_report(sim: dict):
    obs     = sim['detection']['obstacles']
    log     = sim['controller'].log
    s2r     = sim['s2r']
    n_steps = len(log)
    path_wps = len(sim['path'])
    path_len = sum(
        math.hypot(sim['path'][i+1][1]-sim['path'][i][1],
                   sim['path'][i+1][0]-sim['path'][i][0])
        for i in range(len(sim['path'])-1)) if len(sim['path']) > 1 else 0

    obs_rows = ""
    for i, o in enumerate(sorted(obs, key=lambda x: x['dist'])[:10], 1):
        badge_cls = {'CRITICAL':'badge-crit','WARNING':'badge-warn',
                     'CLEAR':'badge-clear'}[o['danger']]
        obs_rows += f"""
        <tr>
          <td>{i}</td>
          <td>({o['center'][0]}, {o['center'][1]})</td>
          <td>{o['dist']} px</td>
          <td>{o['angle']}°</td>
          <td>{o['area']:.0f} px²</td>
          <td><span class="badge {badge_cls}">{o['danger']}</span></td>
        </tr>"""

    log_rows = ""
    for entry in log[:15]:
        safe_cls = "color:#30c060" if entry['safe'] else "color:#f04040"
        log_rows += f"""
        <tr>
          <td>{entry['step']}</td>
          <td>{entry['linear']}</td>
          <td>{entry['angular']}</td>
          <td style="{safe_cls}">{entry['action'][:50]}</td>
        </tr>"""

    s2r_rows = "".join(
        f"<tr><td><strong>{k}</strong></td><td>{v}</td></tr>"
        for k, v in s2r.items())

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Task 6 — AI Indoor Obstacle Avoidance</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Segoe UI',Arial,sans-serif;background:#0a0c10;color:#e8eaf0}}
header{{background:linear-gradient(135deg,#0f3460 0%,#1a1a2e 60%,#16213e 100%);
  padding:32px 40px;border-bottom:1px solid #1e2330}}
h1{{font-size:2rem;letter-spacing:-0.5px}}
h1 span{{color:#4f8ef7}}
.sub{{color:#6b7590;font-size:.85rem;margin-top:6px}}
.container{{max-width:1200px;margin:30px auto;padding:0 24px 60px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:28px}}
.card{{background:#161a22;border:1px solid #1e2330;border-radius:12px;padding:20px;text-align:center}}
.card .num{{font-size:1.8rem;font-weight:700;font-family:monospace}}
.card .lbl{{font-size:.7rem;color:#6b7590;text-transform:uppercase;letter-spacing:1.5px;margin-top:4px}}
.panel{{background:#161a22;border:1px solid #1e2330;border-radius:14px;overflow:hidden;margin-bottom:24px}}
.panel-hdr{{padding:16px 24px;border-bottom:1px solid #1e2330;font-weight:600;color:#4f8ef7;font-size:.95rem}}
.panel-body{{padding:24px}}
table{{width:100%;border-collapse:collapse;font-size:.85rem}}
th{{background:#0f1520;color:#4f8ef7;padding:11px 10px;text-align:left;font-size:.78rem;text-transform:uppercase;letter-spacing:1px}}
td{{padding:9px 10px;border-bottom:1px solid #1e2330}}
tr:hover td{{background:rgba(255,255,255,.02)}}
.badge{{display:inline-block;padding:3px 10px;border-radius:20px;font-size:.75rem;font-weight:700}}
.badge-crit{{background:rgba(240,64,64,.15);color:#f04040}}
.badge-warn{{background:rgba(240,120,32,.15);color:#f07820}}
.badge-clear{{background:rgba(48,192,96,.15);color:#30c060}}
img{{width:100%;border-radius:10px}}
.method-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}}
.method-card{{background:#111318;border:1px solid #1e2330;border-radius:10px;padding:16px}}
.method-card h3{{font-size:.88rem;color:#4f8ef7;margin-bottom:6px}}
.method-card p{{font-size:.78rem;color:#6b7590;line-height:1.6}}
.mono{{font-family:monospace;font-size:.82rem;color:#06b6d4}}
footer{{text-align:center;color:#6b7590;font-size:.78rem;padding:20px}}
</style>
</head>
<body>
<header>
  <h1>🤖 AI-Powered Indoor <span>Obstacle Avoidance</span></h1>
  <div class="sub">Task 6 — Advanced Project &nbsp;·&nbsp;
  Generated: {datetime.now().strftime('%B %d, %Y at %H:%M')} &nbsp;·&nbsp;
  Tech: Python · OpenCV · A* Planning · Control Heuristics</div>
</header>
<div class="container">

  <!-- Summary -->
  <div class="grid">
    <div class="card"><div class="num" style="color:#4f8ef7">{len(obs)}</div><div class="lbl">Obstacles Detected</div></div>
    <div class="card"><div class="num" style="color:#f04040">{sim['detection']['n_critical']}</div><div class="lbl">Critical Zones</div></div>
    <div class="card"><div class="num" style="color:#f07820">{sim['detection']['n_warning']}</div><div class="lbl">Warning Zones</div></div>
    <div class="card"><div class="num" style="color:#30c060">{path_wps}</div><div class="lbl">Path Waypoints</div></div>
    <div class="card"><div class="num" style="color:#e8b020">{path_len:.0f}px</div><div class="lbl">Path Length</div></div>
    <div class="card"><div class="num" style="color:#7c3aed">{n_steps}</div><div class="lbl">Control Steps</div></div>
  </div>

  <!-- Visualizations -->
  <div class="panel">
    <div class="panel-hdr">📊 Full System Visualization</div>
    <div class="panel-body">
      <img src="obstacle_avoidance_results.png" alt="Results"/>
    </div>
  </div>

  <!-- Obstacle Table -->
  <div class="panel">
    <div class="panel-hdr">🔍 Detected Obstacles (Top 10 by Proximity)</div>
    <div class="panel-body">
      <table>
        <thead><tr><th>#</th><th>Center (x,y)</th><th>Distance</th>
          <th>Bearing</th><th>Area</th><th>Status</th></tr></thead>
        <tbody>{obs_rows}</tbody>
      </table>
    </div>
  </div>

  <!-- Control Log -->
  <div class="panel">
    <div class="panel-hdr">🎮 Control Command Log (first 15 steps)</div>
    <div class="panel-body">
      <table>
        <thead><tr><th>Step</th><th>Linear v (m/s)</th>
          <th>Angular ω (rad/s)</th><th>Action</th></tr></thead>
        <tbody>{log_rows}</tbody>
      </table>
    </div>
  </div>

  <!-- Methodology -->
  <div class="panel">
    <div class="panel-hdr">🧠 System Architecture & Methodology</div>
    <div class="panel-body">
      <div class="method-grid">
        <div class="method-card"><h3>📷 Perception (OpenCV)</h3>
          <p>Grayscale → Gaussian blur → Canny edges → Morphological close → Contour detection → Bounding box extraction → Distance estimation.</p></div>
        <div class="method-card"><h3>🗺️ A* Path Planning</h3>
          <p>8-directional grid search with Euclidean heuristic. Obstacle inflation (12px safety margin). Moving-average path smoothing.</p></div>
        <div class="method-card"><h3>🎮 Control Heuristics</h3>
          <p>Pure pursuit lookahead. Reactive obstacle avoidance. Speed scaling near obstacles. Emergency stop on critical detection.</p></div>
        <div class="method-card"><h3>🛡️ Safety Checks</h3>
          <p>3-tier danger zones: CRITICAL (&lt;30px) → STOP, WARNING (&lt;75px) → SLOW, CLEAR → NORMAL. Heading correction per step.</p></div>
        <div class="method-card"><h3>🔁 Sim-to-Real</h3>
          <p>Velocity scaling, distance calibration, sensor noise modeling, actuation lag consideration, ROS topic mapping.</p></div>
        <div class="method-card"><h3>🏠 Real-World Use</h3>
          <p>Service robots, autonomous delivery drones, warehouse AMRs, smart mobility aids for visually impaired.</p></div>
      </div>
    </div>
  </div>

  <!-- Sim-to-Real Table -->
  <div class="panel">
    <div class="panel-hdr">🔧 Sim-to-Real Deployment Checklist</div>
    <div class="panel-body">
      <table>
        <thead><tr><th>Parameter</th><th>Value / Note</th></tr></thead>
        <tbody>{s2r_rows}</tbody>
      </table>
    </div>
  </div>

</div>
<footer>Task 6 — AI-Powered Indoor Obstacle Avoidance &nbsp;·&nbsp;
Slashmark Advanced AI Internship &nbsp;·&nbsp; OpenCV · NumPy · A* Algorithm</footer>
</body></html>"""

    out = os.path.join(OUT_DIR, 'obstacle_avoidance_report.html')
    with open(out, 'w') as f:
        f.write(html)
    print(f"   📄 HTML report saved → {out}")


# ══════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════

if __name__ == '__main__':
    # Start (left room) → Goal (bottom-right room)
    START = (100, 200)   # (x, y) image coordinates
    GOAL  = (500, 320)

    sim = run_simulation(START, GOAL, n_steps=25)
    visualize_all(sim)
    generate_report(sim)

    print("\n" + "="*65)
    print("  ✅  ALL OUTPUTS SAVED TO 'outputs/' FOLDER")
    print("="*65)
    print("  • outputs/floor_plan.png")
    print("  • outputs/detection_result.png")
    print("  • outputs/obstacle_avoidance_results.png")
    print("  • outputs/obstacle_avoidance_report.html")
    print("="*65 + "\n")
